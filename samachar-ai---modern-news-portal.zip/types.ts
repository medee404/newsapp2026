
export interface NewsArticle {
  id: string;
  title: string;
  description: string;
  content: string;
  author: string;
  publishedAt: string;
  url: string;
  urlToImage: string;
  category: string;
}

export enum NewsCategory {
  GENERAL = 'General',
  TECHNOLOGY = 'Technology',
  BUSINESS = 'Business',
  SPORTS = 'Sports',
  ENTERTAINMENT = 'Entertainment',
  HEALTH = 'Health',
  SCIENCE = 'Science'
}

export interface AISummaryResponse {
  summary: string;
  keyPoints: string[];
  sentiment: 'Positive' | 'Neutral' | 'Negative';
}
