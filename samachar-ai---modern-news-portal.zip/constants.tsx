
import { NewsArticle, NewsCategory } from './types';

export const MOCK_NEWS: NewsArticle[] = [
  {
    id: '1',
    title: 'AI Revolutionizes Medical Diagnostics',
    description: 'New AI models are now outperforming doctors in early detection of complex diseases.',
    content: 'Recent breakthroughs in deep learning have enabled artificial intelligence systems to analyze medical imaging with unprecedented accuracy. Clinical trials across leading hospitals show that these systems can identify early-stage tumors that are often missed by human eyes. Researchers believe this will lead to a 40% improvement in survival rates for certain cancers over the next decade.',
    author: 'Dr. Sarah Chen',
    publishedAt: '2023-10-25T10:00:00Z',
    url: '#',
    urlToImage: 'https://picsum.photos/800/400?random=1',
    category: NewsCategory.SCIENCE
  },
  {
    id: '2',
    title: 'Global Markets Rally on Inflation Hopes',
    description: 'Stock indexes across the globe hit record highs as inflation data comes in lower than expected.',
    content: 'Investors are celebrating today as the latest Consumer Price Index report suggests that the central banks\' aggressive rate hikes are finally cooling the economy without triggering a deep recession. The S&P 500 rose 2.5%, while international markets in Tokyo and London also saw significant gains. Analysts predict a stable final quarter for the fiscal year.',
    author: 'James Wilson',
    publishedAt: '2023-10-24T14:30:00Z',
    url: '#',
    urlToImage: 'https://picsum.photos/800/400?random=2',
    category: NewsCategory.BUSINESS
  },
  {
    id: '3',
    title: 'Next-Gen Electric Vehicle Battery Revealed',
    description: 'A startup claims to have developed a solid-state battery that can charge in 5 minutes.',
    content: 'The holy grail of electric vehicles—the solid-state battery—might finally be here. QuantumVolt Energy showcased their prototype today, demonstrating a full charge from 10% to 80% in just under five minutes. This technology not only solves range anxiety but also offers a significantly longer lifespan compared to traditional lithium-ion batteries.',
    author: 'Elena Rossi',
    publishedAt: '2023-10-24T09:15:00Z',
    url: '#',
    urlToImage: 'https://picsum.photos/800/400?random=3',
    category: NewsCategory.TECHNOLOGY
  },
  {
    id: '4',
    title: 'Championship Finals: Underdog Secures Victory',
    description: 'In a stunning upset, the regional newcomers defeated the reigning champions in a nail-biting finish.',
    content: 'The atmosphere was electric at the Grand Stadium as the Thunderbirds took on the Apex Warriors. Against all odds, the Thunderbirds managed a last-minute goal that sealed their first-ever championship title. The fans erupted in celebration, marking what sports commentators are calling the "Miracle of the Season."',
    author: 'Mike Thompson',
    publishedAt: '2023-10-23T21:45:00Z',
    url: '#',
    urlToImage: 'https://picsum.photos/800/400?random=4',
    category: NewsCategory.SPORTS
  }
];
