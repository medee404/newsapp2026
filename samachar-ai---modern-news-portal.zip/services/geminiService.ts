
import { GoogleGenAI, Type } from "@google/genai";
import { AISummaryResponse } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const summarizeArticle = async (content: string): Promise<AISummaryResponse> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Summarize the following news article and provide key points and sentiment analysis.
      Article content: ${content}`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            summary: {
              type: Type.STRING,
              description: 'A concise summary of the article (2-3 sentences).',
            },
            keyPoints: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: 'List of 3-4 major takeaways from the article.',
            },
            sentiment: {
              type: Type.STRING,
              description: 'The overall tone of the article (Positive, Neutral, or Negative).',
            }
          },
          required: ["summary", "keyPoints", "sentiment"]
        }
      }
    });

    return JSON.parse(response.text.trim());
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw new Error("Failed to generate AI summary. Please check your API key.");
  }
};
