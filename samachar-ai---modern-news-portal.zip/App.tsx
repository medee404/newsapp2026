
import React, { useState, useMemo } from 'react';
import Header from './components/Header';
import CategoryBar from './components/CategoryBar';
import NewsCard from './components/NewsCard';
import ArticleModal from './components/ArticleModal';
import AdSlot from './components/AdSlot';
import { NewsArticle } from './types';
import { MOCK_NEWS } from './constants';

const App: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedArticle, setSelectedArticle] = useState<NewsArticle | null>(null);

  const filteredNews = useMemo(() => {
    if (selectedCategory === 'All') return MOCK_NEWS;
    return MOCK_NEWS.filter(article => article.category === selectedCategory);
  }, [selectedCategory]);

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Header />
      <CategoryBar 
        selectedCategory={selectedCategory} 
        onSelectCategory={setSelectedCategory} 
      />

      <main className="flex-grow max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* Top Banner Ad */}
        <AdSlot slotId="BANNER_AD_ID" className="mb-8" />

        {/* Hero Section */}
        {selectedCategory === 'All' && (
          <div className="mb-12 relative rounded-3xl overflow-hidden h-[400px] shadow-2xl group cursor-pointer" onClick={() => setSelectedArticle(MOCK_NEWS[0])}>
            <img 
              src={MOCK_NEWS[0].urlToImage} 
              alt="Breaking News" 
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-1000"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent"></div>
            <div className="absolute bottom-0 left-0 p-8 md:p-12 max-w-3xl">
              <span className="bg-indigo-600 text-white px-3 py-1 rounded text-xs font-bold mb-4 inline-block uppercase tracking-widest">Featured Story</span>
              <h2 className="text-3xl md:text-5xl font-black text-white mb-4 leading-tight">
                {MOCK_NEWS[0].title}
              </h2>
              <p className="text-gray-200 text-lg line-clamp-2 mb-6 opacity-90">
                {MOCK_NEWS[0].description}
              </p>
              <div className="flex items-center text-white/80 text-sm space-x-4">
                <span><i className="fas fa-user-circle mr-2"></i>{MOCK_NEWS[0].author}</span>
                <span><i className="far fa-calendar-alt mr-2"></i>{new Date(MOCK_NEWS[0].publishedAt).toDateString()}</span>
              </div>
            </div>
          </div>
        )}

        <div className="flex items-center justify-between mb-8">
          <h2 className="text-2xl font-black text-gray-900 flex items-center">
            <span className="w-2 h-8 bg-indigo-600 rounded-full mr-3"></span>
            {selectedCategory === 'All' ? 'Latest Stories' : `${selectedCategory} News`}
          </h2>
        </div>

        {filteredNews.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredNews.map((article, index) => (
              <React.Fragment key={article.id}>
                <NewsCard 
                  article={article} 
                  onClick={setSelectedArticle}
                />
                {/* Insert an In-Feed Ad after every 3 articles */}
                {(index + 1) % 3 === 0 && (
                  <div className="md:col-span-2 lg:col-span-1">
                     <AdSlot slotId="FEED_AD_ID" format="fluid" className="h-full flex items-center bg-white border border-gray-100" />
                  </div>
                )}
              </React.Fragment>
            ))}
          </div>
        ) : (
          <div className="text-center py-20 bg-white rounded-2xl border border-dashed border-gray-300">
            <i className="fas fa-search text-4xl text-gray-300 mb-4"></i>
            <h3 className="text-xl font-bold text-gray-900">No news found</h3>
          </div>
        )}

        {/* Newsletter Section */}
        <section className="mt-20 bg-indigo-900 rounded-3xl p-8 md:p-16 text-center text-white relative overflow-hidden shadow-2xl">
          <div className="relative z-10 max-w-2xl mx-auto">
            <h3 className="text-3xl md:text-4xl font-extrabold mb-4">Get the morning headlines</h3>
            <p className="text-indigo-200 text-lg mb-8">Join 50,000+ subscribers who start their day with Samachar AI's intelligent news brief.</p>
            <form className="flex flex-col sm:flex-row gap-3" onSubmit={(e) => e.preventDefault()}>
              <input 
                type="email" 
                placeholder="Enter your email address" 
                className="flex-grow px-6 py-4 rounded-xl bg-white/10 border border-white/20 text-white placeholder:text-white/60 focus:outline-none focus:ring-2 focus:ring-white/40"
              />
              <button className="bg-white text-indigo-900 font-black px-8 py-4 rounded-xl hover:bg-indigo-50 transition-colors shadow-lg">
                SUBSCRIBE
              </button>
            </form>
          </div>
        </section>
      </main>

      <footer className="bg-white border-t mt-20 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-gray-400 text-sm">
          <p>&copy; {new Date().getFullYear()} Samachar AI. All rights reserved.</p>
        </div>
      </footer>

      {/* Article Detail Modal */}
      <ArticleModal 
        article={selectedArticle} 
        onClose={() => setSelectedArticle(null)} 
      />
    </div>
  );
};

export default App;
