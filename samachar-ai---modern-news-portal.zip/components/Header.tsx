
import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="bg-white border-b sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <div className="bg-indigo-600 p-2 rounded-lg text-white mr-3">
              <i className="fas fa-newspaper text-xl"></i>
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900 tracking-tight">
                Samachar <span className="text-indigo-600">AI</span>
              </h1>
              <p className="text-[10px] text-gray-500 uppercase tracking-widest font-semibold">Intelligence in every story</p>
            </div>
          </div>
          
          <div className="hidden md:flex space-x-8">
            <a href="#" className="text-gray-600 hover:text-indigo-600 font-medium">Top Stories</a>
            <a href="#" className="text-gray-600 hover:text-indigo-600 font-medium">Categories</a>
            <a href="#" className="text-gray-600 hover:text-indigo-600 font-medium">About</a>
          </div>

          <div className="flex items-center space-x-4">
            <button className="p-2 text-gray-400 hover:text-indigo-600">
              <i className="fas fa-search"></i>
            </button>
            <button className="p-2 text-gray-400 hover:text-indigo-600">
              <i className="fas fa-bell"></i>
            </button>
            <div className="h-8 w-8 bg-indigo-100 rounded-full flex items-center justify-center text-indigo-600 border border-indigo-200 cursor-pointer">
              <i className="fas fa-user-circle"></i>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
