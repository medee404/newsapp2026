
import React, { useEffect } from 'react';

interface AdSlotProps {
  format?: 'auto' | 'fluid' | 'rectangle';
  slotId?: string;
  className?: string;
}

const AdSlot: React.FC<AdSlotProps> = ({ format = 'auto', slotId = '1234567890', className = '' }) => {
  useEffect(() => {
    try {
      // @ts-ignore
      (window.adsbygoogle = window.adsbygoogle || []).push({});
    } catch (e) {
      console.error('AdSense error:', e);
    }
  }, []);

  return (
    <div className={`my-6 flex justify-center overflow-hidden bg-gray-50/50 rounded-lg border border-dashed border-gray-200 py-2 ${className}`}>
      <ins className="adsbygoogle"
           style={{ display: 'block', width: '100%', textAlign: 'center' }}
           data-ad-client="ca-pub-XXXXXXXXXXXXXXXX"
           data-ad-slot={slotId}
           data-ad-format={format}
           data-full-width-responsive="true"></ins>
    </div>
  );
};

export default AdSlot;
