
import React from 'react';
import { NewsArticle } from '../types';

interface NewsCardProps {
  article: NewsArticle;
  onClick: (article: NewsArticle) => void;
}

const NewsCard: React.FC<NewsCardProps> = ({ article, onClick }) => {
  return (
    <div 
      onClick={() => onClick(article)}
      className="group bg-white rounded-xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 border border-gray-100 cursor-pointer flex flex-col h-full"
    >
      <div className="relative h-48 overflow-hidden">
        <img 
          src={article.urlToImage} 
          alt={article.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
        <div className="absolute top-3 left-3 bg-white/90 backdrop-blur-sm px-2 py-1 rounded text-[10px] font-bold uppercase tracking-wider text-indigo-700 shadow-sm">
          {article.category}
        </div>
      </div>
      
      <div className="p-5 flex-grow flex flex-col">
        <div className="text-xs text-gray-500 mb-2 flex items-center">
          <i className="far fa-clock mr-1"></i>
          {new Date(article.publishedAt).toLocaleDateString()}
          <span className="mx-2 text-gray-300">•</span>
          <span className="truncate">{article.author}</span>
        </div>
        
        <h3 className="text-lg font-bold text-gray-900 group-hover:text-indigo-600 transition-colors mb-3 line-clamp-2">
          {article.title}
        </h3>
        
        <p className="text-sm text-gray-600 line-clamp-3 mb-4 flex-grow">
          {article.description}
        </p>
        
        <div className="flex items-center text-indigo-600 font-semibold text-sm">
          Read Story
          <i className="fas fa-arrow-right ml-2 group-hover:translate-x-1 transition-transform"></i>
        </div>
      </div>
    </div>
  );
};

export default NewsCard;
