
import React, { useState } from 'react';
import { NewsArticle, AISummaryResponse } from '../types';
import { summarizeArticle } from '../services/geminiService';
import AdSlot from './AdSlot';

interface ArticleModalProps {
  article: NewsArticle | null;
  onClose: () => void;
}

const ArticleModal: React.FC<ArticleModalProps> = ({ article, onClose }) => {
  const [summary, setSummary] = useState<AISummaryResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!article) return null;

  const handleSummarize = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await summarizeArticle(article.content);
      setSummary(res);
    } catch (err) {
      setError("Unable to generate summary. Please ensure your Gemini API key is configured.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <div className="bg-white rounded-2xl w-full max-w-4xl max-h-[90vh] overflow-hidden flex flex-col relative animate-in fade-in zoom-in duration-200">
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 z-10 bg-white/50 hover:bg-white p-2 rounded-full transition-colors text-gray-800"
        >
          <i className="fas fa-times text-xl"></i>
        </button>

        <div className="overflow-y-auto flex-grow p-0">
          <img 
            src={article.urlToImage} 
            className="w-full h-[400px] object-cover" 
            alt={article.title} 
          />
          
          <div className="p-6 md:p-10">
            <div className="flex flex-wrap items-center gap-4 mb-6">
              <span className="px-3 py-1 bg-indigo-100 text-indigo-700 text-xs font-bold rounded-full uppercase">
                {article.category}
              </span>
              <span className="text-gray-500 text-sm">
                <i className="fas fa-user-edit mr-2"></i>By {article.author}
              </span>
            </div>

            <h2 className="text-3xl md:text-4xl font-extrabold text-gray-900 mb-6 leading-tight">
              {article.title}
            </h2>

            {/* In-Article Ad Slot */}
            <AdSlot slotId="ARTICLE_AD_ID" format="rectangle" className="mb-8" />

            {/* AI Summary Section */}
            <div className="mb-10 bg-indigo-50/50 rounded-2xl border border-indigo-100 p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center text-indigo-700 font-bold">
                  <i className="fas fa-robot mr-2"></i>
                  Gemini AI Analysis
                </div>
                {!summary && !loading && (
                  <button 
                    onClick={handleSummarize}
                    className="text-sm bg-indigo-600 text-white px-4 py-1.5 rounded-lg hover:bg-indigo-700 transition-colors shadow-sm"
                  >
                    Summarize Article
                  </button>
                )}
              </div>

              {loading && (
                <div className="flex flex-col items-center py-6">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600 mb-2"></div>
                  <p className="text-sm text-indigo-600 font-medium">Analyzing article...</p>
                </div>
              )}

              {summary && (
                <div className="animate-in slide-in-from-top-4 duration-500">
                  <p className="text-gray-800 leading-relaxed italic mb-4">"{summary.summary}"</p>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {summary.keyPoints.map((point, idx) => (
                      <div key={idx} className="flex items-start bg-white p-3 rounded-lg border border-indigo-50 shadow-sm text-sm text-gray-700">
                        <i className="fas fa-check-circle text-indigo-400 mt-1 mr-2"></i>
                        {point}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <div className="prose prose-indigo max-w-none